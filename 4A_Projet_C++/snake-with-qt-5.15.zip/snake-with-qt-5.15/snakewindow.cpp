#include <iostream>
#include <cstdlib>
#include "snakewindow.hpp"

using namespace std;

SnakeWindow::SnakeWindow(QWidget *pParent, Qt::WindowFlags flags):QFrame(pParent, flags)
{
    // Taille des cases en pixels
    int largeurCase, hauteurCase;

    if (pixmapCorps.load("./data/snake_corps.png")==false)
    {
        cout<<"Impossible d'ouvrir snake_corps.png"<<endl;
        exit(-1);
    }

    if (pixmapTete.load("./data/snake_tete.png")==false)
    {
        cout<<"Impossible d'ouvrir snake_tete.png"<<endl;
        exit(-1);
    }

    if (pixmapMur.load("./data/mur.bmp")==false)
    {
        cout<<"Impossible d'ouvrir mur.bmp"<<endl;
        exit(-1);
    }

    if (pixmapFruit.load("./data/apple1.png")==false)
    {
        cout<<"Impossible d'ouvrir apple.png"<<endl;
        exit(-1);
    }

    if (pixmapTerre.load("./data/terre.png")==false)
    {
        cout << "Impossible d'ouvrir terre.png" << endl;
        exit(-1);
    }

    jeu.init();
    spawnFruit();
    timer = new QTimer(this);
    connect(timer, &QTimer::timeout, this, &SnakeWindow::handleTimer);
    timer->start(100);

    largeurCase = pixmapMur.width();
    hauteurCase = pixmapMur.height();

    resize(jeu.getNbCasesX() * largeurCase, jeu.getNbCasesY() * hauteurCase + 50);

    btnAddWall = new SnakeButton(this);
    btnAddWall->setText("Ajout mur");
    btnAddWall->setGeometry(10, 10, 100, 30);

    btnRemoveWall = new SnakeButton(this);
    btnRemoveWall->setText("Suppr mur");
    btnRemoveWall->setGeometry(130, 10, 120, 30);

    // Create the score label and set its initial text
    scoreLabel = new QLabel(this);
    scoreLabel->setText("Score: 0"); // Initial score is zero
    scoreLabel->setGeometry(500, 10, 120, 30); // Adjust the position to the right

    highscoreLabel = new QLabel(this);
    highscoreLabel->setText("Highscore: " + QString::number(jeu.highscore)); // Load and display the highscore
    highscoreLabel->setGeometry(550, 10, 120, 30); // Adjust the position to the right

    levelLabel = new QLabel(this); // Initialize the level label
    levelLabel->setText("Level: 1"); // Initial level is zero
    levelLabel->setGeometry(450, 10, 120, 30); // Position the level label
}

void SnakeWindow::paintEvent(QPaintEvent *)
{
    QPainter painter(this);

    Position pos;

    // Taille des cases en pixels
    int largeurCase, hauteurCase;

    largeurCase = pixmapMur.width();
    hauteurCase = pixmapMur.height();

    // Dessine les cases
for (pos.y = 0; pos.y < jeu.getNbCasesY(); pos.y++) {
    for (pos.x = 0; pos.x < jeu.getNbCasesX(); pos.x++) {
        switch (jeu.getCase(pos)) {
            case MUR:
                painter.drawPixmap(pos.x * largeurCase, pos.y * hauteurCase + 50, pixmapMur);
                break;
            case FRUIT:
                painter.drawPixmap(pos.x * largeurCase, pos.y * hauteurCase + 50, pixmapFruit);
                break;
            case VIDE:
                painter.drawPixmap(pos.x * largeurCase, pos.y * hauteurCase + 50, pixmapTerre);
                break;
            default:
                break;
        }
    }
}

    // Dessine le serpent
    const list<Position> &snake = jeu.getSnake();
    if (!snake.empty())
    {
        list<Position>::const_iterator itSnake;
        const Position &posTete = snake.front();
        painter.drawPixmap(posTete.x * largeurCase, posTete.y * hauteurCase + 50, pixmapTete);

        for (itSnake = ++snake.begin(); itSnake != snake.end(); itSnake++)
            painter.drawPixmap(itSnake->x * largeurCase, itSnake->y * hauteurCase + 50, pixmapCorps);
    }
}

void SnakeWindow::keyPressEvent(QKeyEvent *event)
{
    Direction currentDirection = jeu.getDirection(); // Obtient la direction actuelle du serpent
    Direction newDirection = currentDirection;

    if (event->key() == Qt::Key_Left && currentDirection != DROITE)
        newDirection = GAUCHE;
    else if (event->key() == Qt::Key_Right && currentDirection != GAUCHE)
        newDirection = DROITE;
    else if (event->key() == Qt::Key_Up && currentDirection != BAS)
        newDirection = HAUT;
    else if (event->key() == Qt::Key_Down && currentDirection != HAUT)
        newDirection = BAS;

    // Met � jour la direction du jeu seulement si la nouvelle direction est valide
    if (newDirection != currentDirection) {
        jeu.setDirection(newDirection);
    }

    update();
}

void SnakeWindow::handleTimer() {
    jeu.evolue();

    // Check for collision with walls
    if (jeu.hasCollision()) {
        QMessageBox::information(this, "Game Over", "You hit a wall! Game Over.");
        jeu.saveHighScore(); // Save high score when game over
        jeu.init(); // Reset the game
        spawnFruit(); // Respawn the fruit
        updateScoreLabel(); // Reset the score display to 0
        updateHighScoreLabel(); // Update highscore label after game over
        timer->start(100); // Reset the timer interval to 100ms
        jeu.resetLevel(); // Reset the level to 1
        updateLevelLabel(); // Update the level label
        return;
    }

    // Check for collision with itself
    if (jeu.hasSelfCollision()) {
        QMessageBox::information(this, "Game Over", "You collided with yourself! Game Over.");
        jeu.saveHighScore(); // Save high score when game over
        jeu.init(); // Reset the game
        spawnFruit(); // Respawn the fruit
        updateScoreLabel(); // Reset the score display to 0
        updateHighScoreLabel(); // Update highscore label after game over
        timer->start(100); // Reset the timer interval to 100ms
        jeu.resetLevel(); // Reset the level to 1
        updateLevelLabel(); // Update the level label
        return;
    }

    // Check if the snake's head position matches the position of the fruit
    const Position &headPosition = jeu.getSnake().front();
    if (headPosition == fruitPosition) {
        spawnFruit(); // Spawn a new fruit at a different position
        jeu.increaseSnakeLength(); // Increase the length of the snake
        jeu.score += 10;
        updateScoreLabel(); // Update the score label

        // Check and update the high score
        if (jeu.score > jeu.highscore) {
            jeu.highscore = jeu.score;
            updateHighScoreLabel();
        }

        // Increase level and update timer interval every 100 points
        if (jeu.score % 100 == 0) {
            jeu.increaseLevel();
            updateLevelLabel(); // Update the level label
            updateTimerInterval();
        }
    }

    update();
}

void SnakeWindow::updateTimerInterval() {
    int newInterval = 100 - ((jeu.getLevel() - 1) * 10); // Decrease by 10ms per level
    if (newInterval < 30) {
        newInterval = 30; // Minimum interval of 30 ms to avoid too fast speed
    }
    timer->setInterval(newInterval);
}

void SnakeWindow::addWall() // modifier pour ne pas ajouter des murs sur les positions occippes par le serpent
{
    // G�n�rer des coordonn�es al�atoires pour le mur
    int x = rand() % jeu.getNbCasesX();
    int y = rand() % jeu.getNbCasesY();

    // Assurer que la case est vide avant d'ajouter le mur
    if (jeu.getCase(Position(x, y)) == VIDE) {
        // Ajouter le mur � la position g�n�r�e
        jeu.setCase(Position(x, y), MUR);
        update(); // Actualiser l'affichage
    }
}

void SnakeWindow::removeWall()
{
    // Recherchez un mur al�atoire et retirez-le
    vector<Position> wallsToRemove;

    for (int y = 0; y < jeu.getNbCasesY(); ++y) {
        for (int x = 0; x < jeu.getNbCasesX(); ++x) {
            if (jeu.getCase(Position(x, y)) == MUR) {
                wallsToRemove.push_back(Position(x, y));
            }
        }
    }

    // S'il y a des murs � retirer, choisissez-en un au hasard
    if (!wallsToRemove.empty()) {
        int index = rand() % wallsToRemove.size();
        Position wallToRemove = wallsToRemove[index];

        // Retirez le mur � la position s�lectionn�e
        jeu.setCase(wallToRemove, VIDE);
        update(); // Actualiser l'affichage
    }
}

void SnakeWindow::spawnFruit() {
    // Remove the eaten fruit from its previous position
    jeu.setCase(fruitPosition, VIDE);

    // Generate random coordinates for the new fruit
    int x, y;
    bool positionOk;

    do {
        x = rand() % jeu.getNbCasesX();
        y = rand() % jeu.getNbCasesY();
        Position newFruitPosition(x, y);

        // Check if the position is empty and not occupied by the snake
        positionOk = (jeu.getCase(newFruitPosition) == VIDE);

        if (positionOk) {
            const list<Position> &snake = jeu.getSnake();
            for (const Position &part : snake) {
                if (part == newFruitPosition) {
                    positionOk = false;
                    break;
                }
            }
        }
    } while (!positionOk); // Keep generating until an empty space not occupied by the snake is found

    // Store the position of the new fruit
    fruitPosition = Position(x, y);

    // Place the new fruit at the generated position
    jeu.setCase(fruitPosition, FRUIT);
}

void SnakeWindow::updateScoreLabel() {
    // Update the text of the score label with the current score
    scoreLabel->setText("Score: " + QString::number(jeu.score));
}

void SnakeWindow::updateHighScoreLabel() {
    // Update the text of the highscore label with the current highscore
    highscoreLabel->setText("Highscore: " + QString::number(jeu.highscore));
}

void SnakeWindow::updateLevelLabel() {
    levelLabel->setText("Level: " + QString::number(jeu.getLevel()));
}


