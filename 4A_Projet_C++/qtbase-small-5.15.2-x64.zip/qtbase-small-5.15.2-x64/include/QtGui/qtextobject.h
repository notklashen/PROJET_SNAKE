#include "../../src/gui/text/qtextobject.h"
