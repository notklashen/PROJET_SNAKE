#include "../../src/gui/image/qpictureformatplugin.h"
