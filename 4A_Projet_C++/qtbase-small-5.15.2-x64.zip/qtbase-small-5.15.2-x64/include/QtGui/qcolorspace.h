#include "../../src/gui/painting/qcolorspace.h"
