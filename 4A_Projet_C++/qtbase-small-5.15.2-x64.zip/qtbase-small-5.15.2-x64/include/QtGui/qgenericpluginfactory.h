#include "../../src/gui/kernel/qgenericpluginfactory.h"
