#include "../../src/gui/painting/qcolortransform.h"
