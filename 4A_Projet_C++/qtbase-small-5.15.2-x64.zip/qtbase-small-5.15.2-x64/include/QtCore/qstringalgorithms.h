#include "../../src/corelib/text/qstringalgorithms.h"
