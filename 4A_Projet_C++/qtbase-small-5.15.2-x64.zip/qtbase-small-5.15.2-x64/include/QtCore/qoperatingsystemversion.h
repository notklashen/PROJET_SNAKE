#include "../../src/corelib/global/qoperatingsystemversion.h"
