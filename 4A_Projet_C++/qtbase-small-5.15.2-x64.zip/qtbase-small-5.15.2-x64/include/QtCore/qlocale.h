#include "../../src/corelib/text/qlocale.h"
