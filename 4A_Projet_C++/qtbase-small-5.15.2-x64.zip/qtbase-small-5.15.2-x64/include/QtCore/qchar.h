#include "../../src/corelib/text/qchar.h"
