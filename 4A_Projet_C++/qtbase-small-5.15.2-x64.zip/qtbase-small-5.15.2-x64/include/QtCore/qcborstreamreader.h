#include "../../src/corelib/serialization/qcborstreamreader.h"
