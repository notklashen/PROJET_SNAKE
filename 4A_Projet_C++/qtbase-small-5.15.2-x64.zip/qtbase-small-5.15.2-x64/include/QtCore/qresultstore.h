#include "../../src/corelib/thread/qresultstore.h"
