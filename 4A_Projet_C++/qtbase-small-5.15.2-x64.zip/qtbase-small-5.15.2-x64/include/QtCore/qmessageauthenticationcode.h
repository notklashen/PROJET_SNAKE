#include "../../src/corelib/tools/qmessageauthenticationcode.h"
