#include "../../src/corelib/tools/qarraydataops.h"
