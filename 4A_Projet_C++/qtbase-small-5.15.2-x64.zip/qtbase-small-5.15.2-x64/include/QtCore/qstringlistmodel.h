#include "../../src/corelib/itemmodels/qstringlistmodel.h"
