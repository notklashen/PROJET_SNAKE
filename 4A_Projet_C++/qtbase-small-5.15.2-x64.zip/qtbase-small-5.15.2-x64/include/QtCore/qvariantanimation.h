#include "../../src/corelib/animation/qvariantanimation.h"
