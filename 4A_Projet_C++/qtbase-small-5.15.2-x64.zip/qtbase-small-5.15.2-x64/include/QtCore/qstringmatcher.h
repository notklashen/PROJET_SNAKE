#include "../../src/corelib/text/qstringmatcher.h"
