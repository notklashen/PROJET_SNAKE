#include "../../src/corelib/global/qnumeric.h"
