#include "../../src/corelib/text/qcollator.h"
