#include "../../src/corelib/thread/qatomic_bootstrap.h"
