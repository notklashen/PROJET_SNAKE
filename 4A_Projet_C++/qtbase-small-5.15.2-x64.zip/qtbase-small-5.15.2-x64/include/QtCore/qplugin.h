#include "../../src/corelib/plugin/qplugin.h"
