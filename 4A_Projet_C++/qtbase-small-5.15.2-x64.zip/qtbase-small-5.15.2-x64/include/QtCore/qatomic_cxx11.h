#include "../../src/corelib/thread/qatomic_cxx11.h"
