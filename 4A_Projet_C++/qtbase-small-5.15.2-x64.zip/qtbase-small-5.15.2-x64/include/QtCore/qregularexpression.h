#include "../../src/corelib/text/qregularexpression.h"
