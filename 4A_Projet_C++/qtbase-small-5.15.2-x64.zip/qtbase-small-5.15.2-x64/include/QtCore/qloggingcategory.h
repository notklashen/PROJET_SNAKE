#include "../../src/corelib/io/qloggingcategory.h"
