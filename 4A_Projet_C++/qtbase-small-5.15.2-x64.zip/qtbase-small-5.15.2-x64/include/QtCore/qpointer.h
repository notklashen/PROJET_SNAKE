#include "../../src/corelib/kernel/qpointer.h"
