#include "../../src/corelib/global/qversiontagging.h"
