#include "../../src/corelib/serialization/qcborstream.h"
