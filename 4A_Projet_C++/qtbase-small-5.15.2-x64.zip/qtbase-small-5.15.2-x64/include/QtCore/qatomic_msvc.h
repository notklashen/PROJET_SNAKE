#include "../../src/corelib/thread/qatomic_msvc.h"
