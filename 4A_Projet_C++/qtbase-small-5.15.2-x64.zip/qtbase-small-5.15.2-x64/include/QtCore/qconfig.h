#include "../../src/corelib/global/qconfig.h"
