#include "../../src/corelib/text/qregexp.h"
