#include "../../src/corelib/text/qbytearraymatcher.h"
