#include "../../src/widgets/widgets/qlabel.h"
