#include "../../src/widgets/graphicsview/qgraphicswidget.h"
