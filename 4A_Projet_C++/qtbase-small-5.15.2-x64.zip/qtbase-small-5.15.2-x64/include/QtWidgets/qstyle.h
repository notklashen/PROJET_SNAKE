#include "../../src/widgets/styles/qstyle.h"
