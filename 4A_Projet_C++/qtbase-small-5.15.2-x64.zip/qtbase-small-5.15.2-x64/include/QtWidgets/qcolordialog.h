#include "../../src/widgets/dialogs/qcolordialog.h"
