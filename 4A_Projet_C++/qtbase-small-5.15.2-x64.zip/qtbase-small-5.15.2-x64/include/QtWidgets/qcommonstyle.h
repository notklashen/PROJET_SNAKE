#include "../../src/widgets/styles/qcommonstyle.h"
