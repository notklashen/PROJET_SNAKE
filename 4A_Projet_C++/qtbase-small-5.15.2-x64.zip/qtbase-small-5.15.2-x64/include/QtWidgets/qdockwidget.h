#include "../../src/widgets/widgets/qdockwidget.h"
