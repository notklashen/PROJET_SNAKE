#include "../../src/widgets/util/qscrollerproperties.h"
