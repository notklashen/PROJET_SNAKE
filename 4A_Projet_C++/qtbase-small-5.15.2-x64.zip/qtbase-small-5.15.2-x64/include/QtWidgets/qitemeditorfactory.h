#include "../../src/widgets/itemviews/qitemeditorfactory.h"
