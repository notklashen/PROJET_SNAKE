#include "../../src/widgets/effects/qgraphicseffect.h"
