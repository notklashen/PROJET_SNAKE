#include "../../src/widgets/widgets/qlcdnumber.h"
