#include "../../src/widgets/kernel/qgesture.h"
