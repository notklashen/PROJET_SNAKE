#include "../../src/widgets/kernel/qtwidgetsglobal.h"
