#include "../../src/widgets/widgets/qtextedit.h"
