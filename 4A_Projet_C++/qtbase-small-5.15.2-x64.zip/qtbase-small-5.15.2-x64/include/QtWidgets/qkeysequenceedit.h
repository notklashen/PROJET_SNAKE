#include "../../src/widgets/widgets/qkeysequenceedit.h"
